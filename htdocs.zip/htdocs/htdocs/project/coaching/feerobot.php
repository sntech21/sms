<?php
include 'admin/session.php';
?>

<?php 
include 'php/classes.php';
 	$year = date('Y');
	$class = $_REQUEST['class'];
?>
	
<!DOCTYPE html>
<html>
	<head>
		<title>CCC</title>
		<meta name="viewport" content="initial-scale=1,width=device-width"/>
		<link rel="stylesheet" href="css/bootstrap.min.css" />

		<script src="js/jquery.min.js"></script>
		<script src="js/bootstrap.min.js"></script>
		<style type="text/css">
			*{
				margin:0;
				padding:0;
				box-sizing:border-box;
			}
			
		/*	body{background:linear-gradient(rgba(102, 153, 255,0.3),rgba(255, 102, 102,0.5));}
		*/
		
		body:before{
		background:linear-gradient(rgba(51, 223, 102,0.5),rgba(255, 102, 0,0.5));
		content:'';
		height:100%;
		width:100%;
		position:fixed;
		background-repeat:no-repeat;
		background-position:center;
		-webkit-background-size:cover;
		background-size:cover;
		filter:blur(100px);
		z-index:-1000;
		}
		</style>
	</head>
<body>
<?php include 'nav.php';?>
	<div class="container">
		<br><br>
		<p class="h3 text-center text-danger">Class <?php echo $class;?> Fee Database</p>
		<div class="col-md-10 col-sm-12 col-12 m-auto">
			<div class="row">
				<div class="col-md-4 col-sm-4 col-4">
					<a href="feemanage.php" class="btn btn-danger" >Insert Monthly Fee</a>
				</div>
				
				<div class="col-md-4 col-sm-4 col-4">
					<a href="paid_details.php" class="btn btn-info">Paid Details</a>
				</div>
				
				
				
				<div class="col-md-4 col-sm-4 col-4">
					<input type="text" class="form-control s" id="myInput" onkeyup="myFunction()" placeholder="Search..." style="float:right;margin-bottom:20px">
				</div>
			</div>
		</div><br>
		<table id="myTable" class="table table-bordered table-hover table-striped table-responsive-sm text-center col-md-10 col-sm-12 col-12 m-auto bg-white">
			<tr>
				<th>Roll</th>
				<th>Name</th>
				<th>Fname</th>
				<th>Mobile</th>
				<th>Total</th>
				<th>Edit</th>
			</tr>
			
			<?php 
			
			
			foreach(fee::stfetch($class) as $key => $value){
				$id   = $value[0];
				$name = $value[1];
				$fname = $value[2];
				$roll = $value[5];
				$mobile = $value[6];
				
				foreach(fee::check($id,$year) as $value){
					$total = $value[1] + $value[2] + $value[3] + $value[4] + $value[5] +$value[6]+$value[7]+$value[8]+$value[9]+$value[10]+$value[11]+$value[12];
					echo '<tr>
						<td>'.$roll.'</td>
						<td>'.$name.'</td>
						<td>'.$fname.'</td>
						<td><a href="tel:$mobile">'.$mobile.'</a>  
						<a href="sms:'.$mobile.'?body='.$name.' Your total fee left '.$total.' tk please pay this within 3 days powered by --CCC" class="btn btn-info btn-sm">
						SMS
						</a></td>
						<td>'.$total.'</td>
						<td>
							<a href="feeedit.php?class='.$class.'&id='.$id.'&total='.$total.'" >Edit</a>
						</td>
					</tr>';
					}
				}
			?>
		</table>
	</div>
	
	
	<script> 
	function myFunction() { 
	var input, filter, table, tr, td, i;
	input=document.getElementById("myInput"); 
	filter=input.value.toUpperCase(); 
	
	table=document.getElementById("myTable"); 
	tr=table.getElementsByTagName("tr"); 
	
	for (i = 0; i < tr.length; i++) { td = tr[i].getElementsByTagName("td")[1]; 
	if (td) { 
	if (td.innerHTML.toUpperCase() .indexOf(filter) > -1) {
	tr[i].style.visibility = ""; 
	}
	else {
	tr[i].style.visibility = "collapse"; 
	}
	} 
	}
	}
	</script>
</body>
</html>