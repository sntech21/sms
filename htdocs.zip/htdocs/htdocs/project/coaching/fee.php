<?php
include 'admin/session.php';
?>
<!DOCTYPE html>
<html>
	<head>
		<title>SN Technology</title>
		<meta name="viewport" content="initial-scale=1,width=device-width"/>
		<link rel="stylesheet" href="css/bootstrap.min.css" />

		<script src="js/jquery.min.js"></script>
		<script src="js/bootstrap.min.js"></script>
		<style type="text/css">
			.jumbotron{
				padding:20px 20px;
				background:rgba(255,255,255,0.5);
				color:;
			}
			
			.row{
				margin-top:30px;
			}
			
			body::before{
			content:'';
			height:100%;
			width:100%;
			position:fixed;
			background-image:url("./cimg/fanus.jpg");
			background-repeat:no-repeat;
			background-position:center;
			-webkit-background-size:cover;
			background-size:cover;
			filter:blur(30px);
			z-index:-1000;
			}
		</style>
	</head>
<body>
	<?php include "nav.php";?>
	<div class="container">
		<br>
		<div class="row" >
			<div class="col-md-3 col-sm-12 col-12">
				<div class="jumbotron">
					<h3>Class 1</h3>
					<a href="feerobot.php?class=1" class="btn btn-danger btn-block" >Go</a>
				</div>
			</div>
			
			<div class="col-md-3 col-sm-12 col-12">
				<div class="jumbotron">
					<h3>Class 2</h3>
					<a href="feerobot.php?class=2" class="btn btn-danger btn-block" >Go</a>
				</div>
			</div>
			
			<div class="col-md-3 col-sm-12 col-12">
				<div class="jumbotron">
					<h3>Class 3</h3>
					<a href="feerobot.php?class=3" class="btn btn-danger btn-block" >Go</a>
				</div>
			</div>
			
			<div class="col-md-3 col-sm-12 col-12">
				<div class="jumbotron">
					<h3>Class 4</h3>
					<a href="feerobot.php?class=4" class="btn btn-danger btn-block" >Go</a>
				</div>
			</div>
		</div>
		
		<div class="row" >
			<div class="col-md-3 col-sm-12 col-12">
				<div class="jumbotron">
					<h3>Class 5</h3>
					<a href="feerobot.php?class=5" class="btn btn-danger btn-block" >Go</a>
				</div>
			</div>
		</div>
	</div>
</body>
</html>