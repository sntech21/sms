<?php
include 'admin/session.php';
?>
<?php 
 include 'php/classes.php';
	$class = $_REQUEST['class'];
	$id  = $_REQUEST['id'];
	$year = date('Y');
	$total = $_REQUEST['total'];
?>
	
<!DOCTYPE html>
<html>
	<head>
		<title>CCC</title>
		<meta name="viewport" content="initial-scale=1,width=device-width"/>
		<link rel="stylesheet" href="css/bootstrap.min.css" />

		<script src="js/jquery.min.js"></script>
		<script src="js/bootstrap.min.js"></script>
		<style type="text/css">
			*{
				margin:0;
				padding:0;
				box-sizing:border-box;
			}
			.display{
				padding:10px 10px;
			}
			/*body{background:linear-gradient(rgba(102, 153, 255,0.3),rgba(255, 102, 102,0.5));
			background-size:cover;
			}*/
			body:before{
			background:linear-gradient(rgba(51, 223, 102,0.5),rgba(255, 102, 0,0.5));
			content:'';
			height:100%;
			width:100%;
			position:fixed;
			background-repeat:no-repeat;
			background-position:center;
			-webkit-background-size:cover;
			background-size:cover;
			filter:blur(100px);
			z-index:-1000;
			}
			
			.subcon{padding:20px 20px;}
			.footer{padding:30px 30px; position:absolute; width:100%; margin-top:100%;}
			.m{margin-top:20px;}
		</style>
	</head>
<body>
<?php include 'nav.php';?>
<div class="container">
		<br><br>
	<div class="col-lg-8 col-md-8 col-sm-12 col-12 m-auto text-center bg-white subcon">
		<div class="display m-auto bg-info text-white">
			<h3>Manage Fee</h3>
		</div><br>
		<input type="number" id="amount" class="form-control col-md-5 col-sm-12 col-12 m-auto" placeholder="Enter Amount" >
		<br>
		<select class="form-control col-md-5 col-sm-12 col-12 m-auto" id="month" name="month" >
			<?php 
				$array = ['Select One..','Jan_1','Feb_2','March_3','April_4','May_5','June_6','July_7','Aug_8','Sep_9','Oct_10','Nov_11','Dec_12'];
				for($i = 0; $i < 13; $i++){
					echo "<option>".$array[$i]."</option>";
				}
			?>
		</select>
		<br>
		<input type="number" value="<?php echo $id;?>" readonly="readonly" style="display:none" id="id">
		<input type="password" id="pass" class="form-control col-md-5 col-sm-12 col-12 m-auto" placeholder="Enter Passwored"  >
		<br>
		<div class="row">
			<div class="col-md-6 col-sm-12 col-12 m">
				<button class="plus btn btn-success btn-block">Add</button>
			</div>
			
			<div class="col-md-6 col-sm-12 col-12 m">
				
				<button class="minus btn btn-danger btn-block">Substitute</button>
			</div>
		</div>
	</div>
	
	<br><br>
	<div class="col-md-10 col-sm-12 col-12 m-auto">
		<table class="table table-bordered table-hover table-responsive-sm table-striped bg-white text-center">
			<tr>
				<th>Se No.</th>
				<th>Month</th>
				<th>Left</th>
				<th>Paid Daate</th>
			</tr>
			<?php 
				$i = 1;
				$array = ['Select One..','Jan','Feb','March','April','May','June','July','Aug','Sep','Oct','Nov','Dec'];
				foreach(fee::check($id,$year) as $key => $value){
					$jan = $value[1];
					$feb = $value[2];
					$march = $value[3];
					$april = $value[4];
					$may = $value[5];
					$june = $value[6];
					$july = $value[7];
					$aug = $value[8];
					$sep = $value[9];
					$oct = $value[10];
					$nov = $value[11];
					$dec = $value[12];
					$stid = $value[13];
					$fee_array = ['',$value[1],$value[2],$value[3],$value[4],$value[5],$value[6],$value[7],$value[8],$value[9],$value[10],$value[11],$value[12]];
					
					
				
				for($a = 1; $a < 13; $a++){
					$paid_date = fee::paid_date(strtolower($array[$a]),$stid)[0][0];
					
					$array_count = count(fee::paid_date(strtolower($array[$a]),$stid));
					echo "
						<tr>
							<td>$i</td>
							<td>".$array[$a]."</td>
							<td>".$fee_array[$a]."</td>
					";
					if($array_count > 1){
						echo "<td>".$paid_date." <a href='fee_date_more.php?id=$stid&month=".$array[$a]."'>More</a></td>";
					}
					else{
						echo "<td>".$paid_date."</td>";
					}
					echo "</tr>";
					  $i++;
					}
				}
				
				
			?>
		</table>
	</div>
</div>	

<div class="footer bg-dark text-white">
fghhhhhffffffff
</div>

<script type="text/javascript">
	$(document).ready(function(){
		$('.minus').click(function(){
			var amount = $('#amount').val();
			var passp = prompt('1.want to paid '+amount+'tk \n2.Cancle prossess');
			var month  = $('#month').val(); 
			var pass   = $('#pass').val();
			var id	   = $('#id').val();
			if(passp == '1'){
			$.ajax({
				url:'fee/feeedit.php',
				type:'POST',
				data:{amount:amount,month:month,pass:pass,id:id,process:'paid'},
				success:function(result){
					$('.display').html(result);
					$('#amount').val("");
					$('#pass').val("");
					alert('paid success');
				}
			});}
		});
		
		
		
		
		
		$('.plus').click(function(){
			var amount = $('#amount').val();
			var passp = prompt('1.want to Add '+amount+'tk \n2.Cancle prossess');
			var month  = $('#month').val(); 
			var pass   = $('#pass').val();
			var id	   = $('#id').val();
			if(passp == '1'){
			$.ajax({
				url:'fee/feeedit.php',
				type:'POST',
				data:{amount:amount,month:month,pass:pass,id:id,process:'add'},
				success:function(result){
					$('.display').html(result);
					$('#amount').val("");
					$('#pass').val("");
					alert('Add success');
				}
			});}
		});
	});
</script>
</body>
</html>