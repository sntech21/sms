
<?php
include '../admin/session.php';
?>
<?php
include '../php/classes.php';
?>

<!DOCTYPE html>
<html>
	<head>
		<title>CCC</title>
		<meta name="viewport" content="initial-scale=1,width=device-width"/>
		<link rel="stylesheet" href="../css/bootstrap.min.css" />

		<script src="../js/jquery.min.js"></script>
		<script src="../js/bootstrap.min.js"></script>
		<style type="text/css">
			*{
				margin:0;
				padding:0;
				box-sizing:border-box;
			}
			body{background:#f1f1f1;}
			table, tr, td, th{background:snow; text-align:center;}
			
		</style>
	</head>
	<body>
		<?php include '../nav.php';?>
		<div class="container">
			<br>
			<div class="sub-nav form-inline m-auto float-right">
				<a href="./student.php" id="i" class="btn btn-info">Insert Student</a>
				<select id="sort" onchange="myFunction2(this.value)" class="form-control col-md-3 col-sm-4 col-4">
				<option>Sorted BY</option>
					<?php
						for($i = 1; $i < 13; $i++){
							echo "<option>Class $i</option>";
						}
					?>
				</select>
				<input type="text" class="form-control col-md-4 col-sm-6 col-6 s" id="myInput" onkeyup="myFunction()" placeholder="Search..." >
			</div>
			
		<div id="result">
			
			<?php
			 foreach(students::fetch() as $key => $result){
			 echo '<br><br><table class=" col-lg-11 col-md-11 col-sm-12 col-12 m-auto table table-bordered table-hover table-responsive-sm" id="myTable" >
				<tr>
					<th>Name</th>
					<td>'.$result[1].'</td>
					<td rowspan="3" colspan="3"  ><img src="../st/'.$result[7].''.$result[8].'" height="200px" width="200px"></td>
				</tr>
				<tr>
					<th>Father Nmae</th>
					<td>'.$result[2].'</td>
				</tr>
				<tr>
					<th>Mother Name</th>
					<td>'.$result[3].'</td>
				</tr>
				<tr>
					<th>Class</th>
					<td>'.$result[4].'</td>
					<th>Roll</th>
					<td>'.$result[5].'</td>
				</tr>
				
				<tr>
					<th>Mobile</th>
					<td>'.$result[6].' <a href="tel:'.$result[6].'" class="btn btn-info">Call</a></td>
					<th>Admit Date</th>
					<td>'.$result[9].'</td>
				</tr>
			</table>';
			}
			?>
			</div>
		</div>
<script type="text/javascript">
	function myFunction2(value){
		$.ajax{
			url : 'searchst.php',
			type : 'get',
			data :{value:value},
			success : function(result){
				$('#result').html(result);
			}
		}
	}
</script>
</body>
</html>