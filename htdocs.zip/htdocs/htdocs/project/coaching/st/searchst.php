<?php
include '../php/classes';
	$value = $_REQUEST['value'];
	foreach(students::searchbyclass($value) as $key => $result ){
		
	}
	echo "ddf";
	
?>