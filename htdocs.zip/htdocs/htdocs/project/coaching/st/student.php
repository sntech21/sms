<?php
include '../admin/session.php';
?>

<?php 
include '../php/classes.php';
if(isset($_POST['submit'])){
include 'imageup.php';

$name  = $_REQUEST['name'];
$fname = $_REQUEST['fname'];
$mname = $_REQUEST['mname'];
$class = $_REQUEST['class'];
$roll  = $_REQUEST['roll'];
$mobile = $_REQUEST['mobile'];
$sqlDate = date('Y-m-d'); 
if(students::admit($name, $fname, $mname, $class, $roll, $mobile,$target_dir, $ph_name,$sqlDate) === TRUE){
	echo "Success";
}
else{echo "error";}
}
?>

<!DOCTYPE html>
<html>
	<head>
		<title>CCC</title>
		<meta name="viewport" content="initial-scale=1,width=device-width"/>
		<link rel="stylesheet" href="../css/bootstrap.min.css" />

		<script src="../js/jquery.min.js"></script>
		<script src="../js/bootstrap.min.js"></script>
		<style type="text/css">
			*{
				margin:0;
				padding:0;
				box-sizing:border-box;
			}
			body{background:#f1f1f1;}
			
		</style>
	</head>
	<body>
		<?php include '../nav.php';?>
		<div class="container"><br><br>
			<form action="" method="post" class="form-group col-md-6 col-sm-10 col-12 m-auto" enctype="multipart/form-data">
				<label for="name">Name</label>
				<input type="text" name="name" id="name" class="form-control" placehholder="Name..." autocomplete="off" >
			
				<label for="fname">F. Name</label>
				<input type="text" name="fname" id="fname" class="form-control" placehholder="F Name..." autocomplete="off" >
				
				<label for="mname">M.Name</label>
				<input type="text" name="mname" id="mname" class="form-control" placehholder="M.Name..." autocomplete="off" >
				
				<label for="class">Class</label>
				<input type="text" name="class" id="class" class="form-control" placehholder="Class..." autocomplete="off" >
				
				<label for="roll">Roll</label>
				<input type="text" name="roll" id="roll" class="form-control" placehholder="Roll..." autocomplete="off" >
				
				<label for="mobile">Mobile</label>
				<input type="number" name="mobile" id="mobile" class="form-control" placehholder="Mobile..." autocomplete="off" >
				
				<label for="ph">Photo</label>
				<input type="file" name="fileToUpload" id="fileToUpload" class="form-control">
				<br>
				<input type="submit" value="Submit" class="btn btn-info btn-block" name="submit">
			</form>
		</div>
</body>
</html>