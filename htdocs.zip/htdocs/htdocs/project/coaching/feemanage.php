<?php
include 'admin/session.php';
?>

<?php  
include 'php/classes.php';
	if(isset($_POST['submit'])){
	
		$class  = $_REQUEST['class'];
		$amount = $_REQUEST['range'];
		$m      = $_REQUEST['month'];
		$month  = strtolower($m);
		$year   = date('Y');
		
		foreach(fee::stfetch($class) as $key => $value){
			$id = $value[0];
			if(fee::check($id,$year)){
				if(fee::monthlyup($month,$year,$amount,$id) === TRUE){
				
				}
				
				else{
				echo " failed to update ";
				}
			}
			else{
				if(fee::monthlyin($month,$year,$amount,$id) === TRUE){
					
				}
				
				else{
				echo " failed Insert";
				}
			}
		}
	}
?>

<!DOCTYPE html>
<html>
	<head>
		<title>SN Technology</title>
		<meta name="viewport" content="initial-scale=1,width=device-width"/>
		<link rel="stylesheet" href="css/bootstrap.min.css" />

		<script src="js/jquery.min.js"></script>
		<script src="js/bootstrap.min.js"></script>
		<style type="text/css">
			*{margin:0; padding:0; box-sizing:border-box;}
			body:before{
			background:linear-gradient(rgba(51, 223, 102,0.5),rgba(255, 102, 0,0.5));
			content:'';
			height:100%;
			width:100%;
			position:fixed;
			background-repeat:no-repeat;
			background-position:center;
			-webkit-background-size:cover;
			background-size:cover;
			filter:blur(100px);
			z-index:-1000;
			}
			.img-jumbo{
			background-image:linear-gradient(rgba(0,0,0,0.4),rgba(0,0,0,0.4)), url("cimg/bac.jpg");
			background-size:cover;
			background-position:center;
			}
		</style>
	</head>
<body>
	<?php include "nav.php";?>
	<div class="container"><br><br>
	<div class="jumbotron text-center img-jumbo text-white">
		<h3>SONGAON KINDER GARTEN AND SCHOOL</h3>
	</div>
		<form action="" method="post" class="form-group col-md-8 col-sm-11 col-11 m-auto">
			<label for="class">Class</label>
			<select name="class" id="class" class="form-control" onchange="classcng(this.value)">
				<option>Shishu</option>
				<option>Nursury</option>
				<option>1</option>
				<option>2</option>
				<option>3</option>
				<option>4</option>
				<option>5</option>
			</select>
			<label for="range">Fee Range</label>
			<input type="number" id="range" name="range" class="form-control">
			
			<label for="month">Month</label>
			<select class="form-control" id="month" name="month">
			<?php 
			$array = ['Select One..','Jan','Feb','March','April','May','June','July','Aug','Sep','Oct','Nov','Dec'];
			for($i = 0; $i < 13; $i++){
			echo "<option>".$array[$i]."</option>";
			}
			?>
			</select>
			<br>
			<input type="submit" name="submit" class="btn btn-info btn-block" value="Submit">
		</form>
		<br><br>
	</div>
</body>
</html>