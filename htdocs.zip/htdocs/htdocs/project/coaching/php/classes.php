
<?php

class DB{
	public static $conn;
	public static function connection(){
		self::$conn = new mysqli("localhost","root","","skgs");
		if(self::$conn->connect_error){
			die("connection Failed".self::$conn->connect_error);
		}
		else{

		}
		return self::$conn;
	}
	public static function prepare($sql){
		return self::connection()->query($sql);
	}
}

/*class for students
********************
************************
*/
class students{
	/*admit function or Insert students*/
	public static function admit($name, $fname, $mname, $class, $roll, $mobile, $ph_path, $ph_name,$date){
		
		$sql = "insert into students(name,fname,mname,class,roll,mobile,ph_path,ph_name,admitdate) 
		values('$name','$fname','$mname','$class','$roll','$mobile','$ph_path','$ph_name','$date')
		";
		
		return DB::prepare($sql);
	}


/*Update function*/
public static function update($id,$name, $fname, $mname, $class, $roll, $mobile, $inst, $photo_path, $photo_name){
	$sql = "
	update students set
	name = '$name',
	fname = '$fname',
	mname = '$mname',
	class = '$class',
	roll = '$roll',
	mobile = '$mobile',
	inst = '$inst',
	ph_path = '$photo_path',
	ph_name = '$photo_name' where id=$id
	";
	
	return DB::prepare($sql);
}

	/*function for delete students*/

	public static function delete($id){
		$sql = "delete from students where id=$id ";
		return DB::prepare($sql);
	}
	
	/*FEtch function*/
	public static function fetch(){
		$sql = "select * from students";
		$result = DB::prepare($sql);
		return $result->fetch_all();
	}
}

/*class for result
*************************
************************
*/
	class fee{
		
		/*Insert Fee Range*/
		public static function range($class,$range){
			$sql = "insert into fee(skgfr,class) values('$range','$class')";
			return DB::prepare($sql);
		}
			
		
		/* fetch students for insert or update there monthly fee*/
		public static function stfetch($class){
			$sql = "select * from students where class='$class' ORDER BY roll ASC";
			$result = DB::prepare($sql);
			return $result->fetch_all();
		}
		
		
		public static function feerobot($id,$year){
			$sql = "select * from fee_$year where stid=$id;";
			$result = DB::prepare($sql);
			return $result->fetch_all();
		}
		
		public static function paid_date($month_name,$stid){
			$sql = "select paid_date from paid where stid='$stid' and month='$month_name'";
			$result = DB::prepare($sql);
			return $result->fetch_all();
		}
		
		public static function fetch_paid_by_month($month){
			$sql = "select * from paid where month='$month'";
			$result = DB::prepare($sql);
			return $result->fetch_all();
			
		}
		
		public static function check($id,$year){
			$sql = "select * from fee_$year where stid=$id;";
				$result = DB::prepare($sql);
			return $result->fetch_all();
		}
		
		public static function checkpaid($id){
			$sql = "select * from paid where stid=$id;";
				$result = DB::prepare($sql);
			return $result->fetch_all();
		}
		
		
		public static function monthlyin($month,$year,$amount,$id){
			
			$sql = "insert into fee_$year($month,stid) values('$amount','$id')";
			return DB::prepare($sql);
		}
		
		public static function monthlyup($month,$year,$amount,$id){
			
			$sql = "update fee_$year set 
				$month='$amount' where stid=$id
			";
			return DB::prepare($sql);
		}
		
		public static function paid($id,$month_name,$date){
			$sql = "insert into paid(stid,month,paid_date) values('$id','$month_name','$date')";
			return DB::prepare($sql);
		}
		
		public static function fetch_st_by_id($id){
		$sql = "select * from students where id=$id";
		$result = DB::prepare($sql);
		return $result->fetch_all();
	}
	}
	
	
	class admin{
		
		public static function pass(){
			$sql = "select password from admin";
			$result = DB::prepare($sql);
			$fetch = $result->fetch_all();
			return $fetch[0][0];
		}
		
		public static function num(){
			$sql = "select mobile from admin";
			$result = DB::prepare($sql);
			$fetch = $result->fetch_all();
			return $fetch[0][0];
		}
		
		
		public static function email(){
			$sql = "select email from admin";
			$result = DB::prepare($sql);
			$fetch = $result->fetch_all();
			return $fetch[0][0];
		}
		
	}

?>