<?php
	session_start();
	
	session_destroy();
	
	header('location:http://localhost:8080/htdocs/project/coaching/admin/login.php');
?>