<?php 
session_start();
if(!$_SESSION['admin']){
	header('location:http://localhost:8080/htdocs/project/coaching/admin/login.php');
}
?>
