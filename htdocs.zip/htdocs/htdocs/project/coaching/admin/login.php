<?php
session_start();
include '../php/classes.php';
if(isset($_POST['submit'])){
	$num = $_POST['mobile'];
	$password = $_POST['password'];
	
	if((($num == admin::num() || $num == admin::email() ) && $password == admin::pass() ) === TRUE){
		$_SESSION['admin'] = 1;
		header('location:http://localhost:8080/htdocs/project/coaching/');
	}
	else{
		$msg = "Access Denite";
	}
}
?>
<!DOCTYPE html>
<html>
	<head>
		<title>SN Technology</title>
		<meta name="viewport" content="initial-scale=1,width=device-width"/>
		<link rel="stylesheet" href="../css/bootstrap.min.css" />

		<script src="../js/jquery.min.js"></script>
		<script src="../js/bootstrap.min.js"></script>
		<style type="text/css"></style>
	</head>
<body>
<?php 
include '../nav.php';
?>
	<div class="container">
		<br><br>
		<?php echo $msg;?>
		<form class="form-group col-md-6 col-sm-10 col-10 m-auto" method="post" action="<?php echo $_SERVER['PHP_SELF'];?>">
			<a href="#" class="btn btn-info float-right">Admin</a><br>
			<label for="mobile">Mobile or Email</label>
			<input type="text" id="mobile" name="mobile" class="form-control" placeholder="Enter Number or Email" required="required" autocomplete="off"  >
			<label for="password">Password</label>
			<input type="password" name="password" id="password" class="form-control" placeholder="Enter password" required="required" autocomplete="off" >
			<br>
			<a href="#">Forgotten password?</a>
			<br><br>
			<input type="submit" value="Login" name="submit" class="btn btn-success btn-block">
		</form>
	</div>
</body>
</html>