<?php
include 'admin/session.php';
?>

<!DOCTYPE html>
<html>
	<head>
		<title>CCC Teachers</title>
		<meta name="viewport" content="initial-scale=1,width=device-width"/>
		<link rel="stylesheet" href="css/bootstrap.min.css" />

		<script src="js/jquery.min.js"></script>
		<script src="js/bootstrap.min.js"></script>
		<style type="text/css">
		.row{
		margin-top:40px;
		}
		</style>
	</head>
<body>
<?php include "nav.php";?>
	<div class="container" ><br>
		
		<div class="row" >
			<div class="col-md-5 col-sm-12 col-12" >
				<div class="card" style="width:300px" >
					<img src="cimg/me.jpg" class="card-img-top" >
					<div class="card-body" >
						<h4 class="card-title" >Md Sagor Hossain</h4>
						<p class="card-text" >English Teacher</p>
					</div>
				</div>
			</div>
			
			<div class="col-md-7 col-sm-12 col-12" >
				<table class="table table-borderd table-hover table-responsive-sm" >
					<tr>
						<th colspan="2" class="text-center bg-info text-white h3" >Information</th>
					</tr>
					<tr>
						<th>Home</th>
						<td>Songaon</td>
					</tr>
					
					<tr>
						<th>Student Of</th>
						<td>Kalomegh R Ali High School & College</td>
					</tr>
					
					<tr>
						<th>Class</th>
						<td>Inter 2nd Year</td>
					</tr>
					
					<tr>
						<th>Mobile</th>
						<td>01308163459</td>
					</tr>
					
					<tr>
						<th>E-mail</th>
						<td>snsagorhossain@gmail.com</td>
					</tr>
					
				</table>
			</div>
		</div>
		
		
		
		
		<div class="row" >
			<div class="col-md-5 col-sm-12 col-12" >
				<div class="card" style="width:300px" >
					<img src="cimg/me.jpg" class="card-img-top" >
					<div class="card-body" >
						<h4 class="card-title" >Md Sagor Hossain</h4>
						<p class="card-text" >English Teacher</p>
					</div>
				</div>
			</div>
			
			<div class="col-md-7 col-sm-12 col-12" >
				<table class="table table-borderd table-hover table-responsive-sm" >
					<tr>
						<th colspan="2" class="text-center bg-info text-white h3" >Information</th>
					</tr>
					<tr>
						<th>Home</th>
						<td>Songaon</td>
					</tr>
					
					<tr>
						<th>Student Of</th>
						<td>Kalomegh R Ali High School & College</td>
					</tr>
					
					<tr>
						<th>Class</th>
						<td>Inter 2nd Year</td>
					</tr>
					
					<tr>
						<th>Mobile</th>
						<td>01308163459</td>
					</tr>
					
					<tr>
						<th>E-mail</th>
						<td>snsagorhossain@gmail.com</td>
					</tr>
					
				</table>
			</div>
		</div>
		
	</div>
</body>
</html>