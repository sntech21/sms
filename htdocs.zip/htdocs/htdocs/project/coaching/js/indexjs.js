$(document).ready(function(){
	$("#routine").mouseenter(function(){
		$(".hiddenr").css({"display":"block","transition":"ease-in"});
	});
	
	$("#routine").mouseleave(function(){
		$(".hiddenr").css("display","none");
	});
	
	
	
	$("#student").mouseenter(function(){
		$(".hiddens").css("display","block");
	});
	
	$("#student").mouseleave(function(){
		$(".hiddens").css("display","none");
	});
	
	
	
	$("#teacher").mouseenter(function(){
		$(".hiddent").css("display","block");
	});
	
	$("#teacher").mouseleave(function(){
		$(".hiddent").css("display","none");
	});
	
	
//second row
$("#exam").mouseenter(function(){
		$(".hiddene").css({"display":"block","transition":"ease-in"});
	});
	
	$("#exam").mouseleave(function(){
		$(".hiddene").css("display","none");
	});
	
	
	
	$("#result").mouseenter(function(){
		$(".hiddenresult").css("display","block");
	});
	
	$("#result").mouseleave(function(){
		$(".hiddenresult").css("display","none");
	});
	
	
	
	$("#fee").mouseenter(function(){
		$(".hiddenf").css("display","block");
	});
	
	$("#fee").mouseleave(function(){
		$(".hiddenf").css("display","none");
	});
	
});