<?php
include '../admin/session.php';
?>

<?php
include '../php/classes.php';
	$amount = $_POST['amount'];
	$month_all = $_POST['month'];
	$month_array = explode("_",$month_all);
	$month_numaric = $month_array[1];
	$pass = $_POST['pass'];
	$id  = $_POST['id'];
	$year = date('Y');
	$sqlDate = date('Y-m-d');  
	$month_name = strtolower($month_array[0]);
	
	$process = $_POST['process'];
	
if(admin::pass() == $pass){
	
	if($process == 'paid'){
		foreach(fee::check($id,$year) as $key => $value){
			$month_amount = $value[$month_numaric];
			$left = $month_amount - $amount;
			if(fee::monthlyup($month_name,$year,$left,$id) === TRUE){
				fee::paid($id,$month_name,$sqlDate,$class);
				echo "<h3>$month_name Update Success</h3>";
			}	
				else{
					echo " Failed $month_amount $left ".$month_array[0];
				}
			}
		}
		
		else if($process == 'add'){
			foreach(fee::check($id,$year) as $key => $value){
				$month_amount = $value[$month_numaric];
				$left = $month_amount + $amount;
			if(fee::monthlyup($month_name,$year,$left,$id) === TRUE){
				
				echo "<h3>$month_name Update Success</h3>";
			}	
				else{
					echo " Failed $month_amount $left ".$month_array[0];
				}
			}
		}
	}
	else{
		echo "Password not match";
	}
?>