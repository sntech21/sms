<?php
include '../admin/session.php';
?>
<?php
include '../php/classes.php';
	$class = $_REQUEST['class'];
	$range = $_REQUEST['range'];
	
	if($class == "Nursury"){$class = 100;}
	else if($class == "Shishu"){$class = 101;}
	
	if($range !=""){	
		if(fee::range($class,$range) === TRUE){
			echo "<script>alert('Success');</script>";
		}
	}
?>

<!DOCTYPE html>
<html>
	<head>
		<title>SN Technology</title>
		<meta name="viewport" content="initial-scale=1,width=device-width"/>
		<link rel="stylesheet" href="../css/bootstrap.min.css" />

		<script src="../js/jquery.min.js"></script>
		<script src="../js/bootstrap.min.js"></script>
		<style type="text/css">
		
		</style>
	</head>
<body>
<?php include '../nav.php';?>
	<div class="container">
		<br><br>
		
		<form class="form-group col-md-6 col-sm-10 col-11 m-auto" action="" method="get" >
			<label for="class">Class</label>
			<select class="form-control" id="class" name="class">
				<option>Nursury</option>
				<option>Shishu</option>
				<?php
					for($i = 1; $i < 6; $i++){
						echo "<option>".$i."</option>";
					}
				?>
			</select>
			<label for="range">Fee Range</label>
			<input type="number" id="range" class="form-control" placeholder="Enter Amount.." required="required" name="range" >
			<br>
			<input type="submit" name="submit" class="btn btn-info btn-block" value="Submit">
		</form>
	</div>
</body>
</html>