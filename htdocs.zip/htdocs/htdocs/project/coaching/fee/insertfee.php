
<?php
include '../admin/session.php';
?>
<!DOCTYPE html>
<html>
	<head>
		<title>SN Technology</title>
		<meta name="viewport" content="initial-scale=1,width=device-width"/>
		<link rel="stylesheet" href="../css/bootstrap.min.css" />

		<script src="../js/jquery.min.js"></script>
		<script src="../js/bootstrap.min.js"></script>
		<style type="text/css"></style>
	</head>
<body>
<?php include '../nav.php';?>

<div class="container">
	<br><br>
</div>
</body>
</html>