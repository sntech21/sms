--
-- MySQL 5.1.62
-- Wed, 01 Jan 2014 19:18:37 +0000
--

CREATE TABLE `fee_2020` (
   `id` int(11) unsigned not null auto_increment,
   `jan` int(11),
   `feb` int(11),
   `march` int(11),
   `april` int(11),
   `may` int(11),
   `june` int(11),
   `july` int(11),
   `aug` int(11),
   `sep` int(11),
   `oct` int(11),
   `nov` int(11),
   `dec` int(11),
   PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1;

-- [Table `fee_2020` is empty]