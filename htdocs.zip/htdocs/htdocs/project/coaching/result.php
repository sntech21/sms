<?php
include 'admin/session.php';
?>

<!DOCTYPE html>
<html>
	<head>
		<title>SN Technology</title>
		<meta name="viewport" content="initial-scale=1,width=device-width"/>
		<link rel="stylesheet" href="css/bootstrap.min.css" />

		<script src="js/jquery.min.js"></script>
		<script src="js/bootstrap.min.js"></script>
		<style type="text/css"></style>
	</head>
<body>
	<?php include "nav.php";?>
	<div class="container" >
	<br>
	
		<div class="col-md-6 col-sm-12 col-12 m-auto" >
			<a href="<?php echo $_SERVER["PHP_SELF"];?>" class="float-right" >Reset</a>
			<form class="form-group" >
				<label for="class">Select Class</label>
				<select id="class" name="class" class="form-control"   >
					<?php
						for($i = 1; $i < 11; $i++){
							echo "<option>Class $i</option>";
						}
					?>
				</select>
				
				<label for="month">Select Month</label>
				<input type="month" id="month" class="form-control" name="month"  >
				<label for="roll">Roll</label>
				<input type="number" id="roll" name="roll" class="form-control"><br>
				<input type="submit" class="btn btn-success btn-block" value="Submit" name="submit">
			</form>
		</div>
	</div>
	<?php 
		if(isset($_REQUEST['submit'])){
			include 'marksheet.php';
		}
	?>
</body>
</html>