<div class="container-fluid" >
	<div class="carousel slide" id="myslider" data-ride="carousel"  >
		<div class="carousel-inner" > 
			<div class="carousel-item active" >
				<img src="fwimg/pic.jpg" height="250px" width="100%"  >
				<div class="carousel-caption letbg" >
					<h3 class="text-white">SN TECHNOLOGY</h3>
					<p class="text-white">Codding Tools</p>
				</div>
			</div>
			
			<div class="carousel-item " >
				<img src="fwimg/html.jpg" height="250px" width="100%"  >
				<div class="carousel-caption letbg" >
				<h3 class="text-white">SN TECHNOLOGY</h3>
				<p class="text-white">HTML Codding </p>
				</div>
			</div>
			
			<div class="carousel-item " >
				<img src="fwimg/divice.jpg" height="250px" width="100%"  >
				<div class="carousel-caption letbg" >
				<h3 class="text-white" >SN TECHNOLOGY</h3>
				<p class="text-white" >Digital Device </p>
				</div>
			</div>
		</div>
		
		<ul class="carousel-indicators">
			<li data-target="#myslider" data-slide-to="0" class="active"  ></li>
			<li data-target="#myslider" data-slide-to="1"  ></li>
			<li data-target="#myslider" data-slide-to="2"  ></li>
		</ul>
		
		<a href="#myslider" class="carousel-control-prev" data-slide="prev" >
			<span class="carousel-control-prev-icon" ></span>
		</a>
		
		<a href="#myslider" class="carousel-control-next" data-slide="next" >
			<span class="carousel-control-next-icon" ></span>
		</a>
	</div>
</div>
	