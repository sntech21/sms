<?php
include 'admin/session.php';
?>

<!DOCTYPE html>
<html>
	<head>
		<title>CCC</title>
		<meta name="viewport" content="initial-scale=1,width=device-width"/>
		<link rel="stylesheet" href="css/bootstrap.min.css" />

		<script src="js/jquery.min.js"></script>
		<script src="js/bootstrap.min.js"></script>
		<style type="text/css">
			*{
				margin:0;
				padding:0;
				box-sizing:border-box;
			}
			
			body::before{
			content:'';
			height:100%;
			width:100%;
			position:fixed;
			background-image:url("./cimg/images (36).jpg");
			background-repeat:no-repeat;
			background-position:center;
			-webkit-background-size:cover;
			background-size:cover;
			filter:blur(20px);
			z-index:-1000;
			}
			.conatain {
				position:absolute;
				height:100%;
				width:100%;
				background:;
			}
			.hiddenr,.hiddens,.hiddent,.hiddene,.hiddenresult,.hiddenf{
				display:none;
				margin:;
				padding:;
				position:absolute;
				transition:ease-in;
			}
			/*#result{
				background:linear-gradient(rgba(153,225,102,0.3),rgba(255,51,153,0.3));
			}
			#routine{
				background:linear-gradient(rgba(102, 0, 51,0.3),rgba(102, 102, 255,0.3));
			}
			#student{
				background:linear-gradient(rgba(204, 102, 255,0.3),rgba(255, 200, 102,0.3));
			}
			#fee{
				background:linear-gradient(rgba(51, 153, 102,0.3),rgba(255, 102, 0,0.3),pink);
			}
			
			#exam{
				background:linear-gradient(rgba(51, 153, 102,0.3),rgba(255, 102, 0,0.3),rgba(255,255,255,0.3));
			}
			#teacher{
				background:linear-gradient(rgba(153,225,102,0.3),rgba(255,51,153,0.3));
			}*/
			
			#routine,#student,#teacher,#exam,#result,#fee{
				background:rgba(255,255,255,0.5);
				color:;
				border:2px solid rgba(0,0,0,0.5);
			}
		</style>
	</head>
	<body>
	<div class="conatain" >
		<?php include 'nav.php';?>
			
		<div class="main" >
			<div class="container" ><br>
				<div class="row" >
					<div class="col-md-4 col-sm-12 col-12" >
						<div class="jumbotron" id="routine"  >
							
							<h3>Routine</h3>
							<a href="#" class="btn btn-success btn-large hiddenr" >Go</a>
						</div>
					</div>
					
					<div class="col-md-4 col-sm-12 col-12" >
					<div class="jumbotron" id="student"  >
					
					<h3>Student</h3>
					<a href="st/studentpage.php" class="btn btn-success  hiddens" >Go</a>
					</div>
					</div>
					
					<div class="col-md-4 col-sm-12 col-12" >
					<div class="jumbotron" id="teacher"  >
					
					<h3>Teacher</h3>
					<a href="teacher.php" class="btn btn-success  hiddent" >Go</a>
					</div>
					</div>
				</div>
				
				
				
				<div class="row" >
					<div class="col-md-4 col-sm-12 col-12" >
						<div class="jumbotron" id="exam"  >
							
							<h3>Exam</h3>
							<a href="#" class="btn btn-success  hiddene" >Go</a>
						</div>
					</div>
					
					<div class="col-md-4 col-sm-12 col-12" >
					<div class="jumbotron" id="result"  >
					
					<h3>Result</h3>
					<a href="result.php" class="btn btn-success  hiddenresult" >Go</a>
					</div>
					</div>
					
					<div class="col-md-4 col-sm-12 col-12" >
					<div class="jumbotron" id="fee"  >
					
					<h3>Fee</h3>
					<a href="fee.php" class="btn btn-success  hiddenf" >Go</a>
					</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<script type="text/javascript" src="js/indexjs.js">
		
	</script>
</body>
</html>