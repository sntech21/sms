<?php 
include 'admin/session.php';
include 'php/classes.php';
$year = date('Y');
$class = $_REQUEST['class'];
$month = $_REQUEST['month'];
$array = ['Select One..','Jan','Feb','March','April','May','June','July','Aug','Sep','Oct','Nov','Dec'];
				
?>
<!DOCTYPE html>
<html>
	<head>
		<title>SN Technology</title>
		<meta name="viewport" content="initial-scale=1,width=device-width"/>
		<link rel="stylesheet" href="css/bootstrap.min.css" />

		<script src="js/jquery.min.js"></script>
		<script src="js/bootstrap.min.js"></script>
		<style type="text/css"></style>
	</head>
<body>
<?php include 'nav.php';?>
	<div class="container">
	<br><br>
	<form class="form-group col-md-8 col-sm-10 col-11 m-auto">
		<label for="class">Class</label>
		<input type="number" id="class" name="class" class="form-control" placeholder="Enter Class.." required="required"  >
		<label for="month">Month</label>
		<input type="number" id="month" name="month" class="form-control" placeholder="Enter month"  required="required" >
		
		<br>
		<input type="submit" name="submit" class="btn btn-danger" value="Submit">
	</form>
		<?php
		echo "<table class='table table-hover'> <tr><th>name</th>  <th>Class</th> <th>Roll</th></tr>";
			$month_name = $array[$month];
			echo $month_name;
			foreach(fee::fetch_paid_by_month(strtolower($month_name)) as $key => $value){
				$id = $value[1];
				foreach(fee::fetch_st_by_id($id) as $key => $val){
					$name = $val[1];
					$cls = $val[4];
					$roll = $val[5];
					if($class == $cls){
					echo "<tr>
					<td>".$name."</td>
					<td>".$cls."</td>
					<td>".$roll."</td>
					</tr>";
					}
				}
			}
			echo "</table>";
		?>
	</div>
</body>
</html>