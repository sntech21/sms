<style type="text/css">
#navbar{
position:fixed;
width:100%;
z-index:1000;
}
</style>
<div id="navbar" class="navbar navbar-expand-sm navbar-dark bg-dark " >
		<div class="container" >
			<a href="#" class="navbar-brand"  >Contest Coaching</a>
			<button class="navbar-toggler" data-toggle="collapse" data-target="#navid"  >
				<span class="navbar-toggler-icon" ></span>
			</button>
			<div class="collapse navbar-collapse" id="navid"  >
			<ul class="navbar-nav text-center ml-auto" >
				<li class="nav-item" >
					<a href="http://localhost:8080/htdocs/project/coaching/" class="nav-link"  >Home</a>
				</li>
				
				<li class="nav-item" >
					<a href="#" class="nav-link"  >Contact Us</a>
				</li>
				
				<li class="nav-item" >
					<a href="#" class="nav-link"  >Service</a>
				</li>
				
				<li class="nav-item" >
					<a href="admin/logout.php" class="nav-link"  >Logout</a>
				</li>
			</ul>
		</div>
	</div>
</div>
<br><br>