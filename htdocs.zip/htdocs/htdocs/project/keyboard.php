<!DOCTYPE html>
<html>
<head>
<title></title>
<meta name="viewport" content="initial-scale=0.8,width=device-width"/>
<link rel="stylesheet" href="coaching/css/bootstrap.min.css">
<script src="coaching/js/jquery.min.js"></script>
<style type="text/css">
body{
	background:rgb(224,224,224);
}
	.row-one,.row-two,.row-three,.row-four,.row-five{
		height:80px;
		width:100%;
	}
	button{
		width:60px;
		height:60px;
		margin:3px;
		outline:none;
		border-radius:10px;
		border:none;
		background:rgb(224,224,224);
		box-shadow:5px 5px 10px rgba(0,0,0,0.4), -5px -5px 10px rgba(255,255,255,1);
		font-size:20px;
		color:black;
	}
	button:hover{box-shadow:-5px -5px 10px rgba(0,0,0,0.2), 5px 5px 10px rgba(255,255,255,0.6);}
	.back{width:120px;}
	.tab{width:100px;}
	.caps{width:120px;}
	.shift{width:160px;}
	.other{width:100px;}
	.space{width:300px;}
	.enter{width:130px;}
	.backsl{width:80px;}
	.body{background:;
	 padding:20px 20px;
	 box-shadow:5px 5px 10px rgba(0,0,0,0.2), -5px -5px 10px rgba(255,255,255,0.6);
	 width:1080px;
	 }
</style>

</head>
<body>
<div class="container-fluid">
<br><br><p class="s"></p>
<div class="col-md-11 col-12 m-auto body">
	<div class="row-one">
		<button>`</button>
		<button>1</button>
		<button>2</button>
		<button>3</button>
		<button>4</button>
		<button>5</button>
		<button>6</button>
		<button>7</button>
		<button>8</button>
		<button>9</button>
		<button>0</button>
		<button>-</button>
		<button>=</button>
		<button class="back">Backspace</button>
		
	</div>
	
	<div class="row-two">
		<button class="tab">Tab</button>
		<button>Q</button>
		<button>W</button>
		<button>E</button>
		<button>R</button>
		<button>T</button>
		<button>Y</button>
		<button>U</button>
		<button>I</button>
		<button>O</button>
		<button>P</button>
		<button>{</button>
		<button>}</button>
		<button class="backsl">\</button>
		
	</div>
	
	<div class="row-three">
		<button class="caps">CapsLock</button>
		<button>A</button>
		<button>S</button>
		<button>D</button>
		<button>F</button>
		<button>G</button>
		<button>H</button>
		<button>J</button>
		<button>K</button>
		<button>L</button>
		<button>;</button>
		<button>" '</button>
		<button class="enter">Enter</button>
		
	</div>
	
	<div class="row-four">
		<button class="shift">Shift</button>
		<button>Z</button>
		<button>X</button>
		<button>C</button>
		<button>V</button>
		<button>B</button>
		<button>N</button>
		<button>M</button>
		<button><</button>
		<button>></button>
		<button>?</button>
		<button class="shift">Shift</button>
		
	</div>
	
	<div class="row-five">
		<button class="other">Ctrl</button>
		<button class="other">Win</button>
		<button class="other">Alt</button>
		<button class="space">Space</button>
		<button class="other">Alt</button>
		<button class="other">Ctrl</button>
		
	</div>
</div>
</div>

<script type="text/javascript">
	$(document).ready(function(){
		
	});
</script>

</body>
</html>